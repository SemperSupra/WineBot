"""desktop-ui-cv module."""
